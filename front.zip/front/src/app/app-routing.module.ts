import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersComponent } from './users/users.component';
import { AddUsersComponent } from './add-users/add-users.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';


const routes: Routes = [
  
 
  { path:'add-users', component: AddUsersComponent},
  { path:'users', component: UsersComponent},
  { path:'admin-login', component: AdminLoginComponent},
  {path:'user-login',component:UserLoginComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

