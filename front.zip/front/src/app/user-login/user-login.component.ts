import { Component, OnInit } from '@angular/core';
import { Users, HttpClientService } from '../service/httpclient.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators, FormControlName } from '@angular/forms';



@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

 // user:Users=new Users(0,"","",0,"");
user:Users[];
users:Users=new Users(0,"","",0,"");
 name:string;
 passwordd:string;
 
     constructor(private httpClientService: HttpClientService,private router:Router

  ) { }
ngOnInit(){ 
  
 
    
  }
    
    //console.log(JSON.stringify(this.user));
    
    //if (this.user.userName===name && this.user.password===this.passwordd ){
     // this.userLogin();
    //}
    
    
  //});//kk go n
//}
userLogin() {
  //console.log(this.name,this.passwordd)
  
  //this.httpClientService.userLogin(
   // this.name,this.passwordd).subscribe(data=>{
    //this.httpClientService.userLogin(this.name,this.passwordd).subscribe((data=>this.tr=data));
    //this.httpClientService.getUsers().subscribe(data=>{ this.user=data
   //{
   // if(this.user1.userName===this.name && this.user1.password===this.passwordd){
      //sessionStorage.setItem('name',this.tr);
      //alert("login sucessfully");}
  //});
this.httpClientService.userLogin(this.name,this.passwordd).subscribe((data)=>{
alert(data)});

    }


}




















/*userLogin(name:string,Password:string):void{
  this.httpClientService.userLogin(name,Password).
  subscribe( data =>data.userName===name && data.password===Password);
    {alert("User Regesterd  successfully.");}
   
    console.error("Invalid Username or password");
  

  /* userLogin(name,Password){
if(x=>x.userName===name && x.password===Password){
return alert("Login Sucessfull")
}
else 
return alert('username or password invalid');
  }*/
  
// this.httpClientService.getUsers().subscribe(data=>this.user={
    //this.name:data[this.user.userName];


 /* userLogin():void{
    this.httpClientService.loginUsers(name,this.password);
    if(this.users.userName===name && this.users.password===this.password)

    {
      alert("login sucessfull");}
  
  else{

        alert("Invalid name or password")
  }
  }
  }
   */



/* form=new FormGroup({
name:new FormControl("",Validators.required),
password:new FormControl("",Validators.required)
 });
loginUsers(){
  this.users.userName=this.name;
  this.users.password=this.password;
  this.httpClientService.loginUsers(this.name,this.password).subscribe(
    response=>{
      let result=response.json();
      if(result>0){
        let token=response.header.get("Authorization");
        localStorage.setItem("token",token);
        localStorage.setItem("id",token);
        this.router.navigate(['/user_login',result]);
      }
      if(result==-1){
        alert("Invalid name or password ")
      }
      error=>{
        console.log("Error in authentication");
      }
    }
  );
}
get userName(){
  return this.form.get('name')
}
get Password(){
  return this.form.get("password");
}*/

