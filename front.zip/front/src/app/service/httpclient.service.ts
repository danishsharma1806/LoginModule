import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';


export class Users{
  json: any;
  header: any;
  static find: any;
  constructor(
    public userId:number,
    public userName:string,
    public password:string,
    public userPhone:number,
    public userEmail:string,
  ) {}
  }
export class Admin{
  constructor(
    public adminName:string,
    public adminPassword:string
  ){}

  }

@Injectable({
  providedIn: 'root'
})

export class HttpClientService {
                                                    
  constructor(
    private httpServices:HttpClient ) {}
  
     createUsers(users): Observable<Users> {

    return this.httpServices.post<Users>("http://localhost:8087/user/reg",users,{responseType:'text'as 'json'});
  }

  public userLogin(name:string,passwordd:string) : Observable<Users> {
    //console.log("userName ="+name,"password = "+passwordd);
    return this.httpServices.get<Users>("http://localhost:8087/userLogin/" +name +"/"+passwordd,{responseType:'text' as  'json'});
  }

  public getUsers() {
    console.log("test-call")
    return this.httpServices.get<Users[]>("http://localhost:8087/user/findall",{responseType: 'json'});
  }
  public adminLogin(name:string,password:string){
    return this.httpServices.get<Admin>("http://localhost:8087/adminlogin/"+name+"/"+password,{responseType:'text'as 'json'});
  }
}


