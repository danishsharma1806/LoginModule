import { Component, OnInit } from '@angular/core';
import { HttpClientService,Users } from '../service/httpclient.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-add-users',
  templateUrl: './add-users.component.html',
  styleUrls: ['./add-users.component.css']
})
export class AddUsersComponent implements OnInit {
  users: Users = new Users(0,"","",0,"");
  constructor(
    private httpClientService: HttpClientService,private router:Router ) { }

  ngOnInit(): void {
  }
  
  createUsers(): void {
    
    this.httpClientService.createUsers(this.users).
    subscribe( data => 
      {alert("User Regesterd  successfully.");});

  };


}
