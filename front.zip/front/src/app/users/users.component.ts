import { Component, OnInit } from '@angular/core';
import { Users, HttpClientService } from '../service/httpclient.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  users:Users[];


  constructor(
    private httpClientService: HttpClientService,private router:Router
  ) { }

  ngOnInit() {
    this.httpClientService.getUsers().subscribe(
      response =>{this.users=response
      console.log(JSON.stringify(this.users));
      });



  
  }
 /* userLogin() {
    console.log(this.name,this.passwordd)
   //this.httpClientService.userLogin(this.name,this.passwordd).subscribe((data=>this.users=data));
    
      //this.httpClientService.userLogin(this.name,this.passwordd).subscribe((data=>this.tr=data));
      this.httpClientService.userLogin(this.name,this.passwordd).subscribe(data=>{ 
      if (this.users.userName===name &&this.users.password===this.passwordd ){
     // if(this.user1.userName===this.name && this.user1.password===this.passwordd){
        //sessionStorage.setItem('name',this.tr);
        alert("login sucessfully");}
      
      else{
        alert("Invalid Username Or password");
      }
    });
      }*/
    
  }
  



    
  


