import { Component, OnInit } from '@angular/core';
import { Admin, HttpClientService } from '../service/httpclient.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
admin:Admin=new Admin("","");
  constructor( private httpClientService: HttpClientService,private router:Router ) { 

  }

  ngOnInit(): void {

}
adminLogin() {
  this.httpClientService.adminLogin(this.admin.adminName,this.admin.adminPassword).subscribe((data)=>{
 alert(data)});


}
}