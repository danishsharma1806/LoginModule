package com.capg.login.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cap.login.exceptions.UserException;
import com.capg.login.Entity.UserBean;
import com.capg.login.Service.IUserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController

public class LoginController {
	
	@Autowired
	IUserService service;

	@PostMapping("user/reg")
	public String addUsers(@RequestBody UserBean bean) throws UserException
	{   
		UserBean bean1;
		try
		{
			bean1=service.addNewUser(bean);
		}
		catch(UserException e) 
		{
			return e.getMessage();
		}
		return "Hello " +bean1+" Sucessfully Registered";
	} 

	@GetMapping("/adminlogin/{name}/{password}")   
	public String adminLogin(@PathVariable String name,@PathVariable String password) throws Exception
	{	
		if(name.equals("UrsulaCorbero")&&password.equals("Tokio"))
			return "Admin Login Sucessful...!";
		else 
			return "Invalid name or password";
	}
		 
	@GetMapping("/userLogin/{email}/{password}")
	public String userLogin(@PathVariable String email,@PathVariable String password) throws UserException
	{		
		List<UserBean> bean2;
		try
		{
			bean2= service.userLogin(email, password);	
			boolean flag=false;
			for(UserBean userbean: bean2) 
			{
				if(userbean.getUserName().equals(email.trim())&&userbean.getPassword().equals(password.trim())) 
				{
					flag=true;
					break;
				}
			}
			if(flag==true)
			{
				return("Login Sucessfully......!!!");
			}
			return "Invalid name or password! Try Again...! If not a user please Register.";
		}
		catch(UserException e)
		{
			return e.getMessage();
		}	
	}
	
	@GetMapping("user/findall")    
	public List<UserBean> getall() 
	{
		List<UserBean> bean = service.getAll();
		return bean;
	}
}